/**
 * io-net-batch-topup 主脚本
 *
 * 流程（每个账户）：建链接 → 拿交易 → 签名 → 广播 → 确认。
 * 鉴权：Token（WorkOS JWT）+ Frontend-Version 两个请求头。
 *
 * 用法：node src/index.js accounts.json
 * 详见 README.md 与 docs/。
 */

'use strict';

const fs = require('fs');
const bs58 = require('bs58');
const { Keypair, Connection, VersionedTransaction } = require('@solana/web3.js');

// ===================== 配置 =====================
const CONFIG = {
  RPC: process.env.SOLANA_RPC || 'https://api.mainnet-beta.solana.com',
  AMOUNT: process.env.TOPUP_AMOUNT || '10',            // io.net 最低 10
  FRONTEND_VERSION: process.env.FRONTEND_VERSION || '1.140.0',
  REDIRECT_URL: process.env.REDIRECT_URL ||
    'https://cloud.io.net/cloud/home?credits_purchase=success&amount=10&currency=usdc',
  CONCURRENCY: Number(process.env.CONCURRENCY || 3),
};

const USDC_MINT = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';

// ===================== HTTP 辅助 =====================
function apiHeaders(jwt) {
  return {
    'Content-Type': 'application/json',
    Token: jwt,
    'Frontend-Version': CONFIG.FRONTEND_VERSION,
  };
}

async function postJSON(url, headers, body) {
  const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch (e) { throw new Error(`非 JSON 响应(${res.status}): ${text.slice(0, 200)}`); }
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${JSON.stringify(json).slice(0, 300)}`);
  return json;
}

// ===================== 业务步骤 =====================

/** ① 创建支付链接 */
async function createPaymentLink(jwt) {
  const j = await postJSON(
    'https://api.io.solutions/v1/io-cloud/users/top-up-credits',
    apiHeaders(jwt),
    {
      amount: CONFIG.AMOUNT,
      payment_method: 'crypto',
      redirect_url: CONFIG.REDIRECT_URL,
      resource_id: 'newPurchase',
    },
  );
  if (j.status !== 'succeeded' || !j.data?.payment_link) {
    throw new Error('建链接失败: ' + JSON.stringify(j).slice(0, 200));
  }
  return j.data.payment_link;
}

/** ② 拿待签交易（POST，带 payer 地址；余额不足会抛 insufficient funds） */
async function getTransaction(paymentLinkUrl, pubkey) {
  const id = paymentLinkUrl.split('/').pop();
  const j = await postJSON(
    `https://api.spherepay.co/v1/public/paymentLink/pay/${id}`,
    { 'Content-Type': 'application/json' },
    { account: pubkey },
  );
  if (!j.transaction) throw new Error('拿交易失败: ' + JSON.stringify(j).slice(0, 300));
  return j.transaction;
}

/** ③ 签名 + 广播 + 确认 */
async function signAndSend(secretKey, txB64, conn) {
  const kp = Keypair.fromSecretKey(bs58.decode(secretKey));
  const tx = VersionedTransaction.deserialize(Buffer.from(txB64, 'base64'));
  tx.sign([kp]);
  const sig = await conn.sendRawTransaction(tx.serialize());
  await conn.confirmTransaction(sig, 'confirmed');
  return sig;
}

/** 单账户完整流程 */
async function processAccount(acct, conn) {
  if (!acct.token || !acct.secretKey) throw new Error('缺少 token 或 secretKey');
  const kp = Keypair.fromSecretKey(bs58.decode(acct.secretKey));
  const pubkey = kp.publicKey.toBase58();

  const link = await createPaymentLink(acct.token);
  const txB64 = await getTransaction(link, pubkey);
  const sig = await signAndSend(acct.secretKey, txB64, conn);

  return { email: acct.email, pubkey, link, sig };
}

// ===================== 主流程（并发池） =====================
async function main() {
  const file = process.argv[2] || 'accounts.json';
  const accounts = JSON.parse(fs.readFileSync(file, 'utf8'));
  const conn = new Connection(CONFIG.RPC, 'confirmed');

  console.log(`批量充值：${accounts.length} 个账户，并发 ${CONFIG.CONCURRENCY}`);

  let idx = 0;
  const results = [];

  async function worker() {
    while (true) {
      const i = idx++;
      if (i >= accounts.length) return;
      const acct = accounts[i];
      try {
        const r = await processAccount(acct, conn);
        results.push({ status: 'ok', ...r });
        console.log(`[${i + 1}/${accounts.length}] OK   ${acct.email}  ${r.sig.slice(0, 16)}...`);
      } catch (e) {
        results.push({ status: 'fail', email: acct.email, error: e.message });
        console.error(`[${i + 1}/${accounts.length}] FAIL ${acct.email}: ${e.message}`);
      }
    }
  }

  await Promise.all(Array.from({ length: CONFIG.CONCURRENCY }, () => worker()));

  fs.writeFileSync('results.json', JSON.stringify(results, null, 2));
  const succ = results.filter((r) => r.status === 'ok').length;
  console.log(`\n完成：${succ} 成功 / ${results.length - succ} 失败（明细见 results.json）`);
}

main().catch((e) => {
  console.error('FATAL:', e.message);
  process.exit(1);
});
