# 逆向过程与接口详情（REVERSE ENGINEERING）

> 记录本项目的接口逆向成果，供 review 人员核对。所有接口均为**实测抓包**所得（非官方文档）。

---

## 一、鉴权

`api.io.solutions` 的请求需要两个请求头（HTTP 头大小写不敏感，实测浏览器发送的是首字母大写）：

```http
Token: <WorkOS JWT>
Frontend-Version: 1.140.0
```

- **JWT 来源**：登录后存于 cookie `authPersistedState_1_0`（域名 `.io.net`，值 URL-encoded JSON）：
  `{"status":"authenticated","isReady":true,"token":"<JWT>","userId":"<io_id>","authUserId":"user_...","profile":{...}}`
- **JWT 有效期**：约 1 小时（payload `exp - iat ≈ 3600s`）。
- **刷新**（未完整验证）：cookie `workos_refresh_token`（`.io.net`，httpOnly）→ `POST https://cloud.io.net/api/workos/refresh` → 返回 `{accessToken}`。
- 登录框架为 **WorkOS**（Google/邮箱 SSO）。

## 二、接口清单

### ① 创建支付链接
```http
POST https://api.io.solutions/v1/io-cloud/users/top-up-credits
Content-Type: application/json
Token: <JWT>
Frontend-Version: 1.140.0

{"amount":"10","payment_method":"crypto",
 "redirect_url":"https://cloud.io.net/cloud/home?credits_purchase=success&amount=10&currency=usdc",
 "resource_id":"newPurchase"}
```
响应：
```json
{"status":"succeeded","data":{"payment_link":"https://spherepay.co/pay/paymentLink_xxx"}}
```

### ② 查支付详情（可选）
```http
GET https://api.spherepay.co/v1/public/paymentLink/{paymentLinkId}
```
返回 `lineItems[].id`、`price.currency`（USDC mint `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`）、`price.unitAmount`（如 `10000000` = 10 USDC）等。

### ③ 拿待签交易（核心）
```http
POST https://api.spherepay.co/v1/public/paymentLink/pay/{paymentLinkId}
Content-Type: application/json

{"account":"<payer 钱包公钥 base58>"}
```
- 余额充足 → 预期返回 `{"transaction":"<base64>"}`（**未实测验证成功结构**）。
- 余额不足 → 返回 400，`detail` 含链上模拟日志。

### ④ 查询余额（确认到账）
```http
GET https://api.io.solutions/v1/io-cloud/users/{io_id}/balances
Token: <JWT>
Frontend-Version: 1.140.0
```
返回 `credits_balance` 等。

## 三、交易结构（从余额不足报错日志反推）

```text
Program ComputeBudget111111111111111111111111111111   invoke [1]   // 优先级费
Program AYGdvqsQruZoaJPWsViLqUgtbfXGRnxzgxzW4zmbbckL   invoke [1]   // Spherepay 支付程序
  Program log: Instruction: InitTokenAccountsV1
  Program log: Instruction: TransferV1
  Program TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA   invoke [2]   // SPL token（USDC）
    Program log: Error: insufficient funds
```

结论：交易 = 优先级费 + Spherepay 程序（初始化代币账户 + TransferV1，内部调用 SPL token 做 USDC 转账）。payer 即传入的 `account`。

## 四、实测记录

| 项 | 结果 |
|---|---|
| `top-up-credits`（curl + 两头发） | ✅ 返回 payment_link |
| `pay/{id}` POST（curl） | ✅ 触发服务器模拟，因余额不足报 `insufficient funds` |
| 鉴权头 | ✅ `Token` + `Frontend-Version: 1.140.0` |
| JWT 位置 | ✅ cookie `authPersistedState_1_0` |

## 五、关键未验证点

- `pay/{id}` **成功时**的返回结构（见 `RISKS_AND_ASSUMPTIONS.md` 猜测 1）。
- JWT 刷新请求的完整格式（猜测 3）。
- 邮箱登录端点（猜测 4）。
